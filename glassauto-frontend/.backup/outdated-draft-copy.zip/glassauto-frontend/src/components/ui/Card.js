import { Pressable, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { glassGradient } from '../../theme';

export function Card({ children, onPress, className = '', padded = true, accessibilityLabel }) {
  const body = (
    <>
      <LinearGradient
        pointerEvents="none"
        colors={glassGradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 0.6, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View className={padded ? 'p-4' : ''}>{children}</View>
    </>
  );
  const box = `overflow-hidden rounded-card border border-white/10 bg-carbon ${className}`;
  if (onPress) {
    return (
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel}
        onPress={onPress}
        className={`${box} active:border-white/25 active:bg-graphite`}
      >
        {body}
      </Pressable>
    );
  }
  return <View className={box}>{body}</View>;
}
